using UnityEngine;
using System.Collections;

public class CameraScript : MonoBehaviour {
	
	public Vector3 currPos;
	public Vector3 targetPos;
	public float speed;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		//Debug.Log(transform.position);
		Debug.Log(Screen.width);
		Debug.Log(Screen.height);
		if (Input.mousePosition.x > 0.75*Screen.width){
			transform.Translate(Vector2.right * Time.deltaTime * speed);
		}
		if (Input.mousePosition.x < 0.25*Screen.width){
			transform.Translate(Vector2.right * -Time.deltaTime * speed);
		}
		if (Input.mousePosition.y > 0.75*Screen.height){
			transform.Translate(Vector2.up * Time.deltaTime * speed);
		}
		if (Input.mousePosition.y < 0.25*Screen.height){
			transform.Translate(Vector2.up * -Time.deltaTime * speed);
		}
	}
	
	void OnGUI () {
		
		string description = "test" + System.Environment.NewLine;
		description += "test2";
		if (GUI.Button(new Rect(0F, Screen.height * 0.8F, Screen.width * 0.9F, Screen.height *0.15F), description)){
		}
		
	}
}
