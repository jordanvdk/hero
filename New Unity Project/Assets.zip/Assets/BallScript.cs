using UnityEngine;
using System.Collections;


public class BallScript : MonoBehaviour {
	
	public Vector3 currPos;
	public Vector3 targetPos;
	public bool moveFlag = false;
	public float offset;
	public float speed; 
	public Transform grid;
	public int gridx;
	public int gridy;
	public int movecount;
	public string name;
	
	

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (moveFlag == true){
			currPos = transform.position;
			if (!(currPos.x >= targetPos.x - offset && currPos.x <= targetPos.x + offset)){
				float deltaX = targetPos.x - currPos.x;
				if (deltaX > 0){
					transform.Translate(Vector2.right * Time.deltaTime * speed);		
				}
				else{
					transform.Translate(Vector2.right * -Time.deltaTime * speed);
				}
			}
			else if (!(currPos.y >= targetPos.y - offset && currPos.y <= targetPos.y + offset)){
				float deltaY = targetPos.y - currPos.y;
				if (deltaY > 0){
					transform.Translate(Vector2.up * Time.deltaTime * speed);		
				}
				else{
					transform.Translate(Vector2.up * -Time.deltaTime * speed);
				}
			}
			else{
				moveFlag = false;	
			}	
		}	
	}
	
	void OnMouseDown () {
		currPos = transform.position;
		Camera.main.transform.position = new Vector3(currPos.x, currPos.y, Camera.main.transform.position.z);
		//Camera.main.transform.position.y = currPos.y;
		
	}
}
